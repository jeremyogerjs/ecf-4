
<footer class="text-white d-flex justify-content-center ">
    <?php dynamic_sidebar( 'footer-sidebar' ); ?> 
</footer>


<?php wp_footer(); ?>
</body>
</html>