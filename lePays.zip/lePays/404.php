<?php get_header(); ?>
<div class="container w-25 text-center">
    <p class="text-center">
        Il semblerait que la page que vous cherchez est introuvable
    </p>
    <p>
        Veuillez actualiser la page ou cliquez sur ce <a href="http://localhost/ecf-5">lien</a>
        pour être redirigée
    </p>
</div>

<?php get_footer(); ?>