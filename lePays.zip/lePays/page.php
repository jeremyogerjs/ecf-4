<?php get_header() ?>
<div class="container">
    <p class="text-center"> <?php the_content(); ?></p>
</div>
<?php get_footer() ?>