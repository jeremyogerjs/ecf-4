
<?php get_header(); ?>
<h1>coucou world !</h1>
<button type="button" class="btn btn-primary">Primary</button>
<?php get_footer(); ?>